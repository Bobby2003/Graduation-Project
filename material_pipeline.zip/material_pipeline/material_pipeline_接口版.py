import trimesh
import numpy as np
import os
import math
from PIL import Image


# ==========================================
# 纯几何门框提取器子模块
# ==========================================
def extract_door_geometric(wall_mesh):
    print("启动提取算法...")
    if wall_mesh.is_empty:
        return wall_mesh, trimesh.Trimesh()

    wall_mesh.fix_normals()
    dominant_normal = np.median(wall_mesh.face_normals, axis=0)
    dominant_normal /= np.linalg.norm(dominant_normal)
    centroid = np.median(wall_mesh.vertices, axis=0)

    face_centers = wall_mesh.triangles.mean(axis=1)
    depths = np.dot(face_centers - centroid, dominant_normal)

    MIN_DOOR_DEPTH = 0.1
    MAX_DOOR_DEPTH = 0.25

    door_face_mask = (np.abs(depths) > MIN_DOOR_DEPTH) & (np.abs(depths) < MAX_DOOR_DEPTH)

    door_candidate = trimesh.Trimesh(vertices=wall_mesh.vertices, faces=wall_mesh.faces[door_face_mask])
    door_candidate.remove_unreferenced_vertices()

    main_wall = trimesh.Trimesh(vertices=wall_mesh.vertices, faces=wall_mesh.faces[~door_face_mask])
    main_wall.remove_unreferenced_vertices()

    if door_candidate.is_empty:
        print(f"❌ 深度判定失败")
        return wall_mesh, trimesh.Trimesh()

    door_parts = door_candidate.split(only_watertight=False)
    true_doors = []
    MIN_PART_AREA = 0.1

    for part in door_parts:
        min_y = part.bounds[0][1]
        max_y = part.bounds[1][1]
        is_large_enough = part.area > MIN_PART_AREA
        is_not_ceiling_noise = min_y < 1.5
        is_door_like_height = (min_y < 0.6) or (max_y > 1.2)

        if is_large_enough and is_not_ceiling_noise and is_door_like_height:
            true_doors.append(part)

    if len(true_doors) > 0:
        final_door = trimesh.util.concatenate(true_doors)
        false_doors = [p for p in door_parts if p not in true_doors]
        if false_doors:
            main_wall = trimesh.util.concatenate([main_wall] + false_doors)
        return main_wall, final_door
    else:
        return wall_mesh, trimesh.Trimesh()


# ==========================================
# 核心主处理管线
# ==========================================
# 将 texture_dir 作为参数暴露出去，并赋予默认值
def process_scanned_room(obj_path, output_path, texture_dir=r"C:\毕设\材质\1"):
    """
    模块对外接口：处理扫描房间并赋予 PBR 材质
    :param obj_path: 输入的 obj 模型路径
    :param output_path: 输出的 glb 模型路径
    :param texture_dir: PBR 材质文件夹的路径
    :return: bool, 处理是否成功
    """
    print(f"正在导入模型: {obj_path}")

    # 1. 加载模型
    try:
        mesh = trimesh.load(obj_path, force='mesh')
    except Exception as e:
        print(f"❌ 模型加载失败: {e}")
        return False  # 给总控的失败反馈

    if isinstance(mesh, trimesh.Scene):
        if len(mesh.geometry) == 0:
            return False
        mesh = list(mesh.geometry.values())[0]

    mesh.visual = trimesh.visual.ColorVisuals(mesh=mesh)

    # ==========================================
    # 阶段一：法向量初筛
    # ==========================================
    print("阶段一：启动法向量初筛算法...")
    mesh.fix_normals()

    y_normals = mesh.face_normals[:, 1]
    wall_mask = np.abs(y_normals) < 0.3
    floor_mask = y_normals < -0.7
    ceiling_mask = y_normals > 0.7

    all_vertical_mesh = trimesh.Trimesh(vertices=mesh.vertices, faces=mesh.faces[wall_mask])
    all_vertical_mesh.remove_unreferenced_vertices()

    floor_mesh = trimesh.Trimesh(vertices=mesh.vertices, faces=mesh.faces[floor_mask])
    floor_mesh.remove_unreferenced_vertices()

    ceiling_mesh = trimesh.Trimesh(vertices=mesh.vertices, faces=mesh.faces[ceiling_mask])
    ceiling_mesh.remove_unreferenced_vertices()

    # ==========================================
    # 阶段二：剔除衣柜与垂直家具
    # ==========================================
    print("阶段二：启动连通域分析...")
    room_bounds = mesh.bounds
    min_bound, max_bound = room_bounds[0], room_bounds[1]

    vertical_parts = all_vertical_mesh.split(only_watertight=False)
    true_walls = []
    furniture_verticals = []

    MIN_WALL_AREA = 1
    BOUNDARY_TOLERANCE = 0.5

    for comp in vertical_parts:
        comp_bounds = comp.bounds
        comp_min, comp_max = comp_bounds[0], comp_bounds[1]

        is_large_enough = comp.area >= MIN_WALL_AREA
        touches_outer_shell = (
                abs(comp_min[0] - min_bound[0]) < BOUNDARY_TOLERANCE or
                abs(comp_max[0] - max_bound[0]) < BOUNDARY_TOLERANCE or
                abs(comp_min[2] - min_bound[2]) < BOUNDARY_TOLERANCE or
                abs(comp_max[2] - max_bound[2]) < BOUNDARY_TOLERANCE
        )

        if is_large_enough and touches_outer_shell:
            true_walls.append(comp)
        else:
            furniture_verticals.append(comp)

    initial_wall_mesh = trimesh.util.concatenate(true_walls) if true_walls else trimesh.Trimesh()

    if furniture_verticals:
        furniture_mesh = trimesh.util.concatenate(furniture_verticals)
    else:
        furniture_mesh = trimesh.Trimesh()

    # ==========================================
    # 阶段三：从真墙壁中提取门框
    # ==========================================
    final_wall_mesh, door_mesh = extract_door_geometric(initial_wall_mesh)

    # ==========================================
    # 阶段四：PBR 材质生成与合并
    # ==========================================
    # 使用外部传入的 texture_dir
    base_dir = texture_dir

    # 检查贴图目录是否存在，防止总控调用时崩溃
    if not os.path.exists(base_dir):
        print(f"❌ 找不到材质文件夹: {base_dir}，请总控检查传入路径！")
        return False

    img_ao = Image.open(os.path.join(base_dir, "1_ao.jpg")).convert('L')
    img_rough = Image.open(os.path.join(base_dir, "1_roughness.jpg")).convert('L')
    img_metal = Image.open(os.path.join(base_dir, "1_metallic.jpg")).convert('L')
    target_size = img_ao.size
    img_rough = img_rough.resize(target_size)
    img_metal = img_metal.resize(target_size)
    orm_image = Image.merge('RGB', (img_ao, img_rough, img_metal))

    scifi_material = trimesh.visual.material.PBRMaterial(
        name="True_Wall",
        baseColorTexture=Image.open(os.path.join(base_dir, "1_albedo.jpg")).convert('RGB'),
        normalTexture=Image.open(os.path.join(base_dir, "1_normal.jpg")),
        metallicRoughnessTexture=orm_image,
        occlusionTexture=orm_image
    )

    floor_material = trimesh.visual.material.PBRMaterial(
        name="Floor_Material", baseColorFactor=[40, 40, 45, 255], metallicFactor=0.2, roughnessFactor=0.8
    )

    other_material = trimesh.visual.material.PBRMaterial(
        name="Other_Material", baseColorFactor=[60, 60, 65, 255], metallicFactor=0.1, roughnessFactor=0.9
    )

    # ==========================================
    # 阶段五：物理 UV 计算与装配
    # ==========================================
    tiling = 1.0

    if not final_wall_mesh.is_empty:
        wall_uvs = np.zeros((len(final_wall_mesh.vertices), 2))
        wall_uvs[:, 0] = (final_wall_mesh.vertices[:, 0] + final_wall_mesh.vertices[:, 2]) * tiling
        wall_uvs[:, 1] = final_wall_mesh.vertices[:, 1] * tiling
        final_wall_mesh.visual = trimesh.visual.texture.TextureVisuals(uv=wall_uvs, material=scifi_material)

    if not floor_mesh.is_empty:
        floor_mesh.visual = trimesh.visual.texture.TextureVisuals(
            uv=np.zeros((len(floor_mesh.vertices), 2)), material=floor_material
        )

    if not door_mesh.is_empty:
        door_mesh.visual = trimesh.visual.texture.TextureVisuals(
            uv=np.zeros((len(door_mesh.vertices), 2)), material=other_material
        )
    if not furniture_mesh.is_empty:
        furniture_mesh.visual = trimesh.visual.texture.TextureVisuals(
            uv=np.zeros((len(furniture_mesh.vertices), 2)), material=other_material
        )

    # ==========================================
    # 重新打包并导出
    # ==========================================
    print("正在重新拼装并导出场景...")
    scene_elements = [m for m in [final_wall_mesh, door_mesh, furniture_mesh, floor_mesh, ceiling_mesh] if
                      not m.is_empty]
    final_scene = trimesh.Scene(scene_elements)
    final_scene.export(output_path)
    print(f"✅ 已保存至: {output_path}")

    # 返回成功状态
    return True

# # 测试用代码
# if __name__ == "__main__":
#     teammate_obj = r"C:\毕设\1.obj"
#     final_output = r"C:\毕设\2.glb"
#     if os.path.exists(teammate_obj):
#         process_scanned_room(teammate_obj, final_output)